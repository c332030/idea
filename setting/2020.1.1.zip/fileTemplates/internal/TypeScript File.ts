/**
 * <p>
 *   Description: ${NAME}
 * </p>
 * @author c332030
 * @version 1.0
 */

export const ${NAME} = {
  name: '${NAME}'
};
