#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")

/**
 * <p>
 *   Description: ${NAME} 
 * </p>
 *
 * @author c332030
 * @version 1.0
 */
public enum ${NAME} implements IEnum {

    ${NAME}("${NAME}")
    
    , ${NAME}2("${NAME}2")
    ;

    /**
     * 描述
     */
    private final String text;
    
    ${NAME}(String text) {
        this.text = text;
    }
    
    @Override
    public String getText() {
        return text;
    }
}
