/**
 * <p>
 *   Description: ${NAME}
 * </p>
 * @author c332030
 * @version 1.0
 */

const ${NAME} = {
  name: '${NAME}'
};

export default ${NAME};
