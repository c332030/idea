
import React from "react";

/*
const ${NAME}: React.FC = () => {
  return (
    <>
    </>
  );
};
*/

/**
 * Prop 类型
 */
interface PropTypes {
  
}

/**
 * State 类型
 */
interface StateTypes {
  
}

/**
 * <p>
 *   Description: ${NAME}
 * </p>
 * @author c332030
 * @version 1.0
 */
class ${NAME} extends React.Component <PropTypes, StateTypes> {

  state: StateTypes = {};

//   constructor(props: PropTypes){
//     super(props);
//   }
  
  render(): React.ReactElement<any, string | React.JSXElementConstructor<any>> | string | number | {} | React.ReactNodeArray | React.ReactPortal | boolean | null | undefined {

//     const {} = this.state;

    return (
      <>
      </>
    );
  }
}

export default ${NAME};
