;"use strict";
/**
 * <p>
 *   Description: ${NAME}
 * </p>
 * @author c332030
 * @version 1.0
 */

(function(){
  if (typeof window === 'undefined' || window.${NAME}) {
    return false;
  } else {
    window.${NAME} = this;
    
    this.name = '${NAME}';
  }

}).call({});
