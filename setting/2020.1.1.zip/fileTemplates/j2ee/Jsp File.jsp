<%--
  Description: ${NAME}
  User: c332030
  Version 1.0
--%>
<%@ page contentType="text/html; charset=UTF-8" %>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>#[[$Title$]]#</title>
</head>
<body>
    #[[$END$]]#
</body>
</html>
