/**
 * <p>
 *   Description: ${NAME}
 * </p>
 * @author c332030
 * @version 1.0
 */

export class ${NAME} = {
  name: '${NAME}'
};
