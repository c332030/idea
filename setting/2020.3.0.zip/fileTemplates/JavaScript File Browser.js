;'use strict';
/**
 * <p>
 *   Description: ${NAME}
 * </p>
 * @author c332030
 * @version 1.0
 * @date ${DATE} ${TIME}
 */
(function(){

  if(window.${NAME}) {
    return;
  }

  const ${NAME} = window.${NAME} = {};

  function init(){};

  init();
})();
