
import React from "react";

/*
const ${NAME}: React.FC = () => {
  return (
    <>
    </>
  );
};
*/

/**
 * Prop 类型
 */
interface ${NAME}PropTypes {
  
}

/**
 * State 类型
 */
interface ${NAME}StateTypes {
  
}

/**
 * <p>
 *   Description: ${NAME}
 * </p>
 * @author c332030
 * @version 1.0
 * @date ${DATE} ${TIME}
 */
export class ${NAME} extends React.Component <${NAME}PropTypes, ${NAME}StateTypes> {

  state: ${NAME}StateTypes = {};

//   constructor(props: ${NAME}PropTypes){
//     super(props);
//   }
  
  render(): React.ReactElement<any, string | React.JSXElementConstructor<any>> | string | number | {} | React.ReactNodeArray | React.ReactPortal | boolean | null | undefined {

//     const {} = this.state;

    return (
      <>
      </>
    );
  }
}
