
/**
 * <p>
 *   Description: ${NAME}
 * </p>
 * @author c332030
 * @version 1.0
 * @date ${DATE} ${TIME}
 */
export class ${NAME} {}
