#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")

/**
 * <p>
 *   Description: ${NAME} 
 * </p>
 *
 * @author c332030
 * @version 1.0
 */
public enum ${NAME} {
}
